import { Component } from '@angular/core';

@Component({
  selector: 'app-quotes-cancelled',
  templateUrl: './quotes-cancelled.component.html',
  styleUrl: './quotes-cancelled.component.css'
})
export class QuotesCancelledComponent {

}
