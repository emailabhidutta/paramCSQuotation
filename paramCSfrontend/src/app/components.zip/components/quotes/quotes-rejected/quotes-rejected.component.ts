import { Component } from '@angular/core';

@Component({
  selector: 'app-quotes-rejected',
  templateUrl: './quotes-rejected.component.html',
  styleUrl: './quotes-rejected.component.css'
})
export class QuotesRejectedComponent {

}
