import { Component } from '@angular/core';

@Component({
  selector: 'app-quotes-accepted',
  templateUrl: './quotes-accepted.component.html',
  styleUrl: './quotes-accepted.component.css'
})
export class QuotesAcceptedComponent {

}
